n = ARGV[0].to_i

suma = " "
n.times do |i|
    i += 1
    suma += "#{i}"
    puts suma
end